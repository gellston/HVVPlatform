#include "v8pp/config.hpp"

#if !V8PP_HEADER_ONLY
#include "v8pp/json.ipp"
#endif
