#include "v8pp/config.hpp"

#if !V8PP_HEADER_ONLY
#include "v8pp/throw_ex.ipp"
#endif
