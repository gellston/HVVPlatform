#include "v8pp/version.hpp"

#if !V8PP_HEADER_ONLY
#include "v8pp/version.ipp"
#endif
